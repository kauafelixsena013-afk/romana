import React, { useState } from 'react'

export default function Login({ onLogin }){
  const [user, setUser] = useState('')
  const [pass, setPass] = useState('')
  const [err, setErr] = useState('')

  const submit = (e) => {
    e.preventDefault()
    // credenciais fixas: romana / 1234
    if(user === 'romana' && pass === '1234'){
      onLogin({ username: 'romana', role: 'Operador' })
    } else {
      setErr('Usuário ou senha inválidos.')
    }
  }

  return (
    <div className="login-wrap">
      <div className="card">
        <h2 style={{margin:0}}>Login</h2>
        <p style={{color:'#374151',marginTop:6}}>Acesse o painel (usuário: <strong>romana</strong> / senha: <strong>1234</strong>)</p>
        <form onSubmit={submit} style={{marginTop:12}}>
          <div className="form-row">
            <label>Usuário</label>
            <input className="input" value={user} onChange={e=>setUser(e.target.value)} />
          </div>
          <div className="form-row">
            <label>Senha</label>
            <input type="password" className="input" value={pass} onChange={e=>setPass(e.target.value)} />
          </div>
          <div style={{display:'flex',gap:10,alignItems:'center'}}>
            <button className="btn" type="submit">Entrar</button>
            <button type="button" className="smallbtn" onClick={()=>{setUser('romana'); setPass('1234')}}>Preencher exemplo</button>
          </div>
          {err && <div style={{color:'#ef4444',marginTop:8}}>{err}</div>}
        </form>
      </div>
    </div>
  )
}
