import React from 'react'
import Machine from './Machine'

export default function Dashboard({ onLogout, user }){
  // 7 máquinas enumeradas M01..M07, painel zerado (status inicial = Ociosa)
  const maquinas = Array.from({length:7}, (_,i)=>({
    id: `M0${i+1}`,
    status: 'Ociosa',
    tempo: '--:--',
    producao: 0
  }))

  return (
    <div>
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:18}}>
        <div>
          <h2 style={{margin:0}}>Painel de Máquinas</h2>
          <div className="header-sub">Lista de máquinas (toque para abrir painel individual)</div>
        </div>
        <div style={{display:'flex',gap:8}}>
          <button className="smallbtn" onClick={onLogout}>Sair</button>
        </div>
      </div>

      <div className="card" style={{marginBottom:14}}>
        <div className="list">
          {maquinas.map(m=>(
            <a key={m.id} className="machine-link" href={`#${m.id}`} style={{textDecoration:'none',color:'#111'}}>
              <div style={{display:'flex',flexDirection:'column'}}>
                <div style={{fontWeight:700}}>{m.id}</div>
                <div className="meta">Status: <span className="status-empty">Ociosa</span></div>
              </div>
              <div>
                <button className="btn" style={{background:'#0f766e'}}>Abrir</button>
              </div>
            </a>
          ))}
        </div>
      </div>

      <div style={{marginTop:18}}>
        <h3 style={{marginBottom:8}}>Painel rápido (visão geral)</h3>
        <div className="grid">
          {maquinas.map(m=>(
            <Machine key={m.id} machine={m} />
          ))}
        </div>
      </div>

      <div style={{marginTop:18}} className="card">
        <h3 style={{margin:0}}>Observações</h3>
        <p style={{color:'#6b7280',marginTop:8}}>Ao clicar em uma máquina (Abrir) será navegada a âncora do id. Em versão completa, cada link abriria painel individual com apontamento via QR/mobile. Este protótipo é a base para upload na Vercel.</p>
      </div>
    </div>
  )
}
