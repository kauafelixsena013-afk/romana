import React from 'react'

export default function Machine({ machine }){
  // machine: { id, status, tempo, producao }
  const badge = (s) => {
    if(s.includes('Produz')) return {color:'#fff',bg:'#16a34a'}
    if(s.includes('Parada')) return {color:'#fff',bg:'#ef4444'}
    if(s.includes('Setup')) return {color:'#111',bg:'#f59e0b'}
    return {color:'#111',bg:'#e6e6e6'}
  }

  const b = badge(machine.status)
  return (
    <div className="card">
      <div className="machine-id">{machine.id}</div>
      <div style={{marginTop:8}}>
        <span className="badge" style={{background:b.bg,color:b.color}}>{machine.status}</span>
      </div>
      <div className="meta">⏱️ {machine.tempo}</div>
      <div className="meta">🧵 {machine.producao} peças</div>
      <div style={{marginTop:10}}>
        <button className="smallbtn">Apontar (simulado)</button>
      </div>
    </div>
  )
}
