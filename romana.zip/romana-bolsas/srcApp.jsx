import React, { useState } from 'react'
import Login from './Login'
import Dashboard from './Dashboard'

export default function App(){
  const [user, setUser] = useState(() => {
    const s = sessionStorage.getItem('romana_user')
    return s ? JSON.parse(s) : null
  })

  const handleLogin = (u) => {
    sessionStorage.setItem('romana_user', JSON.stringify(u))
    setUser(u)
  }

  const handleLogout = () => {
    sessionStorage.removeItem('romana_user')
    setUser(null)
  }

  return (
    <>
      <div className="header">
        <h1>ROMANA BOLSAS</h1>
        <div style={{display:'flex',gap:10,alignItems:'center'}}>
          {user && <div style={{color:'#fff',fontWeight:700}}>{user.role}</div>}
        </div>
      </div>

      <div className="container">
        {!user ? (
          <Login onLogin={handleLogin} />
        ) : (
          <Dashboard onLogout={handleLogout} user={user} />
        )}
      </div>
    </>
  )
}
